Stripe Mission and Values
* PayPal began in 1999
* Stripe helps increase the GDP of the internet
* Stipe is a payment processor, help pay business on line easily, seamlessly, 
* Build products on top of the core goal, all in one payment processor
* Card issuing, fraud protection, querying
* 1 million businesses use stripe and trust them to manage billions of dollars
* 85% of American adults bought something on Stripe last year.
* 200 million API requests per day
* 2000 Employees across 13 global offices
* Stripe Atlas become legal entities in America

Your Priorities
* Knowing and understanding the concepts billing and subscription is important

Product Updates
* Billing
* Additional support
* Billing thresholds, invoice
* Historical - receipts, refunds

Payments
* 
