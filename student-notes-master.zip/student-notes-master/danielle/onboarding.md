# danielles notes
## terminal commands
- `New-Item <file.js>` - creates new item
- `mkdir <file name>` - creates new directory 


## git commands
- `git status` - check what files changed
-   git add <file name>` staging file to be added 
- git commit -m "message of commit"
- git push 