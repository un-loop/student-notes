## Sean O'Dell 06/01/2020
## Calculator: HTML & CSS

?why specify the same class for all buttons when some will be formatted differently?
a:one can add multiple classes for the same element (only one class declaration, separate classes with 'space'), and can stack elements with different classes

put borders on elements to delineate where elements start/end

safe to use height when so additional content will be added to element (not if you just don't plan to add more content, plans change)

**last-child selector - selects the last child of a given element to apply styling to.
-   <elem>:last-child {}