## Sean O'Dell 05/29/2020
## Website Embeds & GitHub Pages

## fonts and images
font-awesome contains massive repository of free and premium icons that can be modified with CSS

google fonts contains server with database for fonts. avoid excessive use of fonts, 2 is plenty

**iFrame - tag that opens another page within the page containing it

## GitHub intro

- set up GitHub account
- commit files to repository
- push commit
- set up website with github.io