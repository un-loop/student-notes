## Sean O'Dell 06/02/2020
## Calaculator Project: Javascript

better many small functions instead of few large functions. "Functions should do one thing and do it well"