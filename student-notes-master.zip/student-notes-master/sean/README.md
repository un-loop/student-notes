## Sean O'Dell
## NOTE GLOSSARY

## **<TERM> - <DEFINITION>
definition of term

## <NOTE>
## -<SUBNOTE>
related sub-point of note above OR part of list 

##

## ?<NOTE>?
question OR thought for later expansion/review

## a<NUM>:<NOTE>
answer or clarification on question (will be either located directly below ?<NOTE>? OR <NUM> = line # of related <NOTE>)

## sum:<SUMMARY>
short summary/takeaway (not available in all notes)