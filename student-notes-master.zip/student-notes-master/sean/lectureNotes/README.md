## Sean O'Dell
## Lecture notes

Each set of notes should contain the date, the speaker's name, and the topic at or near the head of the document