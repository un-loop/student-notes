STRIPE LECTURE

-Online payments processer
-Empower developers, move quick, grow reveue
-Grow global commerce online
-Global payments & treasury network
-People paying buisnesses & vice virsa
-All in one payment processor
-Whent public in 2011
-Building buisness infastructure
-Additional suppor for data in stripe sigma
-Billing thresholds issur invoice, create & send branded invoices securly
-13 langurages supported
-Stripe Connect= find, prioritize & manage your commected accounts in the dashboard
-Set up your own Stripe Connecg accunt for your own biz
-Connect & disconect with other buisnesses
-Stripe is full access & Express is a limited access account
-Smart payment page that works on any device
-Works accross countrys, languages, and currencys