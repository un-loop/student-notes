COMMANDS
View---toggle word wrap
command+shift+f = search your code for a certin thing

SHORT CUTS IN NODE

Cont ~ to open terminal
ls=  list of all files
mkdir=  make new folder
cd= change directory
touch= new file
code . = open new dir in vs code
command B= removes side bar
command S= save
mv <file> <folder>
rm -rf <name of file you want deleted>


git clone <url>
git add <file name>
Got add  . (To add all files)
git status
git commit -m “add read.me file”
git push
got checkout -b “make new branch name"

npm i -g <package name>
npm i <package name> —save (dash dash save)
if get permissions error add sudo before same command
