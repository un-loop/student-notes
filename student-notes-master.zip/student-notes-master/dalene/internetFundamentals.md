-The Client = the device in front of you it runs some kind of web browser.
-Web Browser = Software that runs on the client that displays web pages
-Server = Where your public website lives
-Hardware server = the physical computer that serves up web pages
-Software server = the program that runs to serve up the web pages(Apache)
-IP address = is your computers address
-Internet service providers givs you internet access

-Your modem is your point of clarity
*ISPs provide the IP address to the modem or router in your house
*You may have another level of IP addresses within your house for your devices
*To the outside world all of your home internet traffic looks the same

-THE CLOUD = just another name for the internet

-HTTP VS HTTPS =Hypertext Transfer Protocol-foundation of data communication for the web
* S is secure aids in security during data transmission

-Web Hosting = Websites live on servers
* you dont have a server at your house
* you can rent server space  web hosting service
-Pricing & services a good host =
* updates the server and keeps it secure
* provides high uptime(active & avalable)
* provides reasonable bandwidth(data transfer)
*provides techical support as needed

-FTP = File Transfer Protocol(geting your web page on the internet)
* create web files organized in folders on your coputer
* trasnfer the files and any folders to the web host 
* fileZilla client is good free software for this
* web host will tell you how to connect with FTP

-Domain Name = address for your website
* many different endings for these but most common and best known is .com
* host provides a teporary address
-Good domain names
* easy to spell
* not to long
* easy to say over the phone
* easy to remember
* avoid hyphens and numbers
* avoid copyright and trademark issues
-What to rigister
* start with your own name
* you can register names and not use them
* you can have more then one name point to the same website("parking")
-www.nameboy.com = help pick a name
-where to purchase 
* domain name registrar
* sometimes the same as the hosting company(namecheap)
-Connect name to hosting
* DNS: domain name system
* translates name to IP address
* DNS settings provided by hosting company
* takes 48-72 hous to iplement

-Best development web browsers are Chrome & Firefox
-Diffrent browsers have diffrent levels of support for programing
-Technologies that run in a browser
* HTML * CSS * JavaScript

--FILES & FOLDERS--
-Every device has files & folders
-Files are pieces of info we can look at
-Folders just group files together
-About files = music, videos, databases, images, documents, programs etc.
* can be reeated, opened, seved, renamed, printed, emailed, and modified
* have an extension of 3-4 characters after a dot
* take up room on your hard drive
-About folders
* only one kind
* does only one thing (holds files or more folders)
* can be created mived renamed deleted
* opened wihin the file system not opened llike a program or document
* are ther for your convienence organized in a way that makes sense to you
-only typs of imiges supporded on the wab are * .jpg, .jpeg, .gif, .png
