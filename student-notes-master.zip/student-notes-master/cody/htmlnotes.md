#HTML Notes

##Tags
- `<p>-Paragraph`
-`<h1>`Heading 1 is the largest
-`<h6>` is the smallest heading
-`<ul>` unordered list (bullet points)
-`<ol>` ordered list(numbers)
-`<li>` list item
-`<br>` line break
-`<blockquote>` used for longer quotes
-`<cite>` Citing work by someone
-`<a>` create a link uses href
-`<img>` image alt is to describe the picture
-`<strong>` to make the text bold
-`<em>` to make the text italic


