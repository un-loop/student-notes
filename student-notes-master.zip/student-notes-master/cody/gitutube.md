## Git hub notes from youtube

## What is git
- Distributed Versionmangement system
-Having version controll allows you to track what you have worked on and what other team members are working on.
-
## What is github?
-Github is a webbased platform used for version control. It simplifies the process of working with other people and allows for multipul team memebers to work on a project together.

## Resolving a github merge conflict