# Pair Programming with Misha on 6-3

## Stuff I learned
- if you leave empty [] brackets in a function at the end will say you only want it to run once. However if you put a variable into the [] it will run everytime you use that variable.
-Flexbox width default value is 100%
-when creating a object put each property on it's own seperate line
-If you put the widtch to a certain % when using flex box if you use 100% it will put each item on it's own line
-
## Questions
-What is a react hook?
-- Hooks are functions that let you “hook into” React state and lifecycle features from function components. ... React provides a few built-in Hooks like useState . You can also create your own Hooks to reuse stateful behavior between different components.
-bootstrap grid
-- go watch you tube video
-what is use effect?