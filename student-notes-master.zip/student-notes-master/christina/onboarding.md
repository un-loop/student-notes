# On Boarding
## git commands
- `git status` - shows you what changes are diff compared to the last commit
- `git add  <fileName>` stages the changes you want to commit your choice
- `git commit -m "pushing to master"` green sqaures 
- `git push` pushes my forked code up to the repository